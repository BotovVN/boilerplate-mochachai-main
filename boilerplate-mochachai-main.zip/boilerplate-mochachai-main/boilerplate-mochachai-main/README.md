# Quality Assurance with Chai

Это шаблон для обеспечения качества с уроками Chai.Инструкции по завершению этих уроков начинаются с https://www.freecodecamp.org/learn/quality-assurance/quality-assurance-and-testing-with-chai/
